package mobile;

import java.util.*;

class VegeCustomer {
	int groceryNumber;
	String customername;
	float quantity;
	String groceryName;
	float price;
	int order_id;
	Node1 next;

	VegeCustomer(float quantity, String groceryName, float price, int groceryNumber, int orderid) {
		next = null;
		this.groceryName = groceryName;
		this.quantity = quantity;
		this.price = price;
		this.groceryNumber = groceryNumber;
		this.order_id = orderid;
	}
}

class Node1 {
	Scanner sc = new Scanner(System.in);
	int groceryNumber;
	String customername;
	float quantity = 0;
	String groceryName;
	float price;
	int customerid = 1;
	int orderid = 1;
	Node1 next;
	VegeCustomer arr[];

	Node1(String customername, int customerid) {
		this.customername = customername;
		this.customerid = customerid;
		Scanner sc = new Scanner(System.in);

		System.out.println("M E N U");
		System.out.println("A. Vegetables \t\t Price per kg");
		System.out.println("\t 1. Tomato \t\t 15/-");
		System.out.println("\t 2. Lady Finger \t 30/-");
		System.out.println("\t 3. Potato \t\t 40/-");
		System.out.println("\t 4. Cauli flower \t 20/-");

		System.out.println();
		System.out.println("B. Fruits \t\t Price per kg");
		System.out.println("\t 5. Apple \t\t 50/-");
		System.out.println("\t 6. Banana \t\t 40/-");
		System.out.println("\t 7. Mango \t\t 50/-");
		System.out.println("\t 8. Custard Apple \t 100/-");

		System.out.println("Enter the number of Order: ");
		int size = sc.nextInt();
		arr = new VegeCustomer[size];
		next = null;
	}

	void insertOrder(int customer_id) {
		for (int i = 0; i < arr.length; i++) {

			System.out.println("Enter the Grocery Number: ");
			groceryNumber = sc.nextInt();

			if (groceryNumber == 1) {
				System.out.println("Enter the Quantity in KG: ");
				quantity = sc.nextFloat();
				price = (float) 15;
				groceryName = "Tomato";
				price = price * quantity;
				System.out.println("Tomato Added");

				VegeCustomer vg = new VegeCustomer(quantity, groceryName, price, groceryNumber, orderid);
				arr[i] = vg;
				orderid++;
			}

			else if (groceryNumber == 2) {
				System.out.println("Enter the Quantity in KG: ");
				quantity = sc.nextFloat();
				price = (float) 30;
				groceryName = "Lady Finger";
				price = price * quantity;
				System.out.println("Lady Finger Added");
				VegeCustomer vg = new VegeCustomer(quantity, groceryName, price, groceryNumber, orderid);

				arr[i] = vg;
				orderid++;
			} else if (groceryNumber == 3) {
				System.out.println("Enter the Quantity in KG: ");
				quantity = sc.nextFloat();
				price = (float) 30;
				groceryName = "Potato";
				price = price * quantity;
				System.out.println("Lady Finger Added");

				VegeCustomer vg = new VegeCustomer(quantity, groceryName, price, groceryNumber, orderid);
				arr[i] = vg;
				orderid++;
			}

			else if (groceryNumber == 4) {
				System.out.println("Enter the Quantity in KG: ");
				quantity = sc.nextFloat();
				price = (float) 30;
				groceryName = "Cauli flower";
				price = price * quantity;
				System.out.println("Lady Finger Added");

				VegeCustomer vg = new VegeCustomer(quantity, groceryName, price, groceryNumber, orderid);
				arr[i] = vg;
				orderid++;
			}

			else if (groceryNumber == 5) {
				System.out.println("Enter the Quantity in KG:: ");
				quantity = sc.nextFloat();
				price = (float) 30;
				groceryName = "Apple";
				price = price * quantity;
				System.out.println("Lady Finger Added");

				VegeCustomer vg = new VegeCustomer(quantity, groceryName, price, groceryNumber, orderid);
				arr[i] = vg;
				orderid++;
			}

			else if (groceryNumber == 6) {
				System.out.println("Enter the Quantity in KG: ");
				quantity = sc.nextFloat();
				price = (float) 30;
				groceryName = "Banana";
				price = price * quantity;
				System.out.println("Lady Finger Added");

				VegeCustomer vg = new VegeCustomer(quantity, groceryName, price, groceryNumber, orderid);
				arr[i] = vg;
				orderid++;
			}

			else if (groceryNumber == 7) {
				System.out.println("Enter the Quantity in KG: ");
				quantity = sc.nextFloat();
				price = (float) 30;
				groceryName = "Mango";
				price = price * quantity;
				System.out.println("Lady Finger Added");

				VegeCustomer vg = new VegeCustomer(quantity, groceryName, price, groceryNumber, orderid);
				arr[i] = vg;
				orderid++;
			}

			else if (groceryNumber == 8) {
				System.out.println("Enter the Quantity in KG: ");
				quantity = sc.nextFloat();
				price = (float) 30;
				groceryName = "Custard Apple";
				price = price * quantity;
				System.out.println("Lady Finger Added");

				VegeCustomer vg = new VegeCustomer(quantity, groceryName, price, groceryNumber, orderid);
				arr[i] = vg;
				orderid++;
			} else {
				System.out.println("Enter the valid choice");
			}

		}
	}

	void billPrint() {
		int total = 0;
		System.out.println("Your Bill is :");
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == null) {
				continue;
			}
			System.out.println();
			System.out.println("Order no: " + arr[i].order_id);
			System.out.println("Customer name" + arr[i].customername);
			System.out.println("Grocery Name :" + arr[i].groceryName);
			System.out.println("Quantity Number : " + arr[i].quantity);
			System.out.println("Grocery price :" + arr[i].price);
			total += arr[i].price;
			System.out.println();
		}
		System.out.println("Total price: " + total);
	}

	void search() {
		int flag = 0;

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == null) {
				continue;
			}
			System.out.println("Order no " + arr[i].order_id);
			System.out.println("Grocery Name :" + arr[i].groceryName);
			System.out.println("Quantity Number : " + arr[i].quantity);
			System.out.println("Grocery price :" + arr[i].price);
			System.out.println();
		}

	}

	void orderDelete() {

		int flag = 0;
		System.out.println("Enter the Order number for order deletion: ");
		int groceryno = sc.nextInt();

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == null) {
				continue; // Skip null elements
			}
			if (arr[i].order_id == groceryno) {
				arr[i] = null; // Delete the order by setting it to null
				System.out.println("Order Deleted");
				flag = 1;
				break;
			}
		}

		if (flag == 0) {
			System.out.println("Order with Order number " + groceryno + " does not exist.");
		}

	}

	void displayproduct() {

		for (int i = 0; i < arr.length; i++) {

			if (arr[i] == null) {
				continue;
			}
			System.out.println("Order no " + arr[i].order_id);

			System.out.println("Grocery Name :" + arr[i].groceryName);
			System.out.println("Quantity Number :" + arr[i].quantity);
			System.out.println("Grocery price :" + arr[i].price);
			System.out.println();
		}

	}
}

class VegeFruits {
	Node1 head;
	String customer_name;
	int customer_id = 1;
	Scanner sc = new Scanner(System.in);

	VegeFruits() {
		head = null;
	}

	void create() {
		System.out.println("Enter customer name :");
		customer_name = sc.next();
		Node1 temp = new Node1(customer_name, customer_id);

		temp.insertOrder(customer_id);
		if (head == null) {
			head = temp;
		} else {
			Node1 ptr = head;
			while (ptr.next != null) {
				ptr = ptr.next;
			}
			ptr.next = temp;
		}
		customer_id++;
	}

	void display_node() {
		Node1 ptr = head;
		if (ptr == null) {
			System.out.println("No customers available");
		} else {

			while (ptr != null) {
				System.out.println("Order displayed:-");
				System.out.println("Customer name is:" + ptr.customername + " ");
				System.out.println("Customer id is:" + ptr.customerid + " ");

				ptr.displayproduct();

				ptr = ptr.next;
				System.out.println("-------------------------------------------");
			}
		}
	}

	void search() {
		int flag = 0;

		Node1 temp = head;

		if (head == null) {
			System.out.println("No customers available");
		} else {
			System.out.println("Enter the Customer ID you want to search: ");
			int searchnumber = sc.nextInt();
			while (temp != null) {

				if (temp.customerid == searchnumber) {

					flag = 1;
					break;
				}
				temp = temp.next;
			}
			if (flag == 1) {
				temp.search();
			} else {
				System.out.println("Customer  not found");
			}
		}
	}

	void lldelete() {
		Node1 ptr;
		ptr = head;
		int flag = 0;

		Node1 temp = head;
		if (head == null) {
			System.out.println("No customers available");
		} else {
			System.out.println("Enter the Customer ID whose order you want to delete: ");
			int searchnumber = sc.nextInt();
			while (temp != null) {
				if (temp.customerid == searchnumber) {

					flag = 1;
					break;
				}
				temp = temp.next;
			}
			if (flag == 1) {
				temp.orderDelete();
			} else {
				System.out.println("Customer  not found");
			}
		}
	}

	void customerdelete() {
		Node1 ptr = null;
		Node1 curr = head;
		int flag = 0;

		if (curr == null) {
			System.out.println("No Customers available");
		} else {
			System.out.println("Enter customer ID whose bill to be generated");
			int deletecustomerid = sc.nextInt();

			if (curr != null && deletecustomerid == curr.customerid) {
				head = curr.next;
				curr.billPrint();
				System.out.println(" Customer orders is deleted");
				return;
			}

			while (curr != null && curr.customerid != deletecustomerid) {

				flag = 1;

				ptr = curr;

				curr = curr.next;

			}

			if (curr == null) {
				System.out.println("Customer not found");
				return;
			}
			ptr.next = curr.next;

			if (flag == 1) {
				curr.billPrint();
			} else {
				System.out.println("No customer found");
			}

			System.out.println("Customer node is successfully deleted");

		}
	}
}

class de_project_cummins {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		VegeFruits veg = new VegeFruits();

		int ch = 0;

		do {
			System.out.println("*****Welcome to Grocery Section!**********");
			System.out.println("1.Order\n2.Search\n3.Display\n4.Delete particular order\n5.Generate Bill");
			System.out.println("Enter the choice :");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				veg.create();
				break;

			case 2:
				veg.search();
				break;

			case 3:
				veg.display_node();
				break;

			case 4:
				veg.lldelete();
				break;

			case 5:
				veg.customerdelete();
				break;

			/*
			 * case 5: v1.billGeneration(); break;
			 */

			default:
				System.out.println("Invalid Case");
				break;
			}
			System.out.println("Do you want to continue 1/0");
			ch = sc.nextInt();

		} while (ch != 0);

	}
}
