package mobile;

import java.util.Scanner;

public class Main {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		CustomerList cus = new CustomerList();
		System.out.println("**********************************************************************************");
		System.out.println("***************************WELCOME TO SHOPPING CENTER*****************************");
		System.out.println("----------------------------------------------------------------------------------");
		VegeFruits veg = new VegeFruits();
		int ch1, ch;
		do {
			System.out.println("1.Buy a Mobile\n2.Buy Grocery");
			System.out.println("----------------------------------------------------------------------------------");
			System.out.println("Enter the choice :");
			
			ch = sc.nextInt();
			if (ch == 1) {
				do {
				System.out.println(
						"*******************Mobile Menu*******************\n0.Exit\n1.Buy a Mobile \n2.Search a Mobile \n3.Display List \n4.Delete Customer \n5.Bill Generation");
				System.out.println("Enter the choice :");
				int choice = sc.nextInt();
				switch (choice) 
				{
				case 1:
					cus.create();
					break;
				case 2:
					cus.search();
					break;
				case 3:
					cus.display_node();
					break;
				case 4:
					cus.delete_node();
					break;
				case 5:
					cus.billGeneration();
					break;
				case 0:
					break;
				default:
					System.out.println("Please choose correct choice .");
					break;
				}
				System.out.println("Do you want to continue (1/0) :");
				ch = sc.nextInt();
				}while(ch!=0);
			} 
			else if (ch == 2) {
				do {
					System.out.println("*******************Grocery Menu*******************\n0.Exit\n1.Buy Grocery Item \n2.Search Item\n3.Display Items\n4.Delete Item\n5.Bill Generation");
					System.out.println("Enter the choice :");
					int choice = sc.nextInt();

					switch (choice) {
					case 1:
						veg.create();
						break;

					case 2:
						veg.search();
						break;

					case 3:
						veg.display_node();
						break;

					case 4:
						veg.lldelete();
						break;

					case 5:
						veg.customerdelete();
						break;
					/*
					 * case 5: v1.billGeneration(); break;
					 */
					case 0:
						break;
					default:
						System.out.println("Invalid Case");
						break;
					}
					System.out.println("Do you want to continue (1/0) :");
					ch = sc.nextInt();
				}while(ch!=0);
			}
			System.out.println("Do you want to Buy any thing else (1/0):");
			ch=sc.nextInt();
		}while (ch != 0);
		System.out.println("-------------------------------------------------------");
		System.out.println("Thank you for visiting Shopping Center !");
	}
}
