package mobile;

import java.util.Scanner;
class Product {
	int quantity;
	String productname;
	float price;
	int product_id;
	String color;
	int ram;
	String companyname;
	Product next;
	float amount;

	Product(int quantity, float price, int product_id, String color, int ram, String companyname, float amount) {
		next = null;
		this.quantity = quantity;
		this.price = price;
		this.product_id = product_id;
		this.color = color;
		this.ram = ram;
		this.companyname = companyname;
		this.amount = amount;
	}
}
class Node {
	Scanner sc = new Scanner(System.in);
	int groceryNumber;
	String customername;
	int quantity = 0;
	String groceryName;
	float price;
	int customerid = 1;
	Node next;
	Product arr[];
	int mobstock1 = 50;
	int mobstock2 = 100;
	int mobstock3 = 150;
	int mobstock4 = 200;
	Node temp;
	int ram;
	String color;
	int productid = 1;
	int companyname;
	String company;
	float amount;
	int qun = 0;
	Node(String customername, int customerid) {
		this.customername = customername;
		this.customerid = customerid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of Order: ");
		int size = sc.nextInt();
		arr = new Product[size];
		next = null;
	}
	void insertOrder() {

		for (int i = 0; i < arr.length; i++) {
			System.out.println("M E N U");
			System.out.println("1. Oneplus ");
			System.out.println("2. Oppo ");

			System.out.println("Enter the choice of mobile company: ");
			companyname = sc.nextInt();

			if (companyname == 1) {
				company = "Oneplus";
				System.out.println("1 for range less than 10,000");
				System.out.println("2 for range between 10,000 to 50,000");
				
				System.out.println("Enter expected Price range choice:");
				int pricerange = sc.nextInt();
				if (pricerange == 1) {
					// price = 5000;
					System.out.println("As per your choice we have:");
					System.out.println("Ram = 128 gb, color = Black, Price = Rs.5000");
					System.out.println("We have available mobile stock of " + mobstock1);
					System.out.println("Please enter the quantity you want:");
					qun = sc.nextInt();
					if (qun <= mobstock1) {
						ram = 128;
						color = "black";
						price = 5000;
						mobstock1 = mobstock1 - qun;
						amount = price * qun;
						Product pro = new Product(qun, price, productid, color, ram, company, amount);
						arr[i] = pro;
						System.out.println("Order is placed");
					} else if (qun > mobstock1) {
						System.out.println("Sorry! Stock not available");
						System.out.println("Current stock is:");
						System.out.println(mobstock2);
					}
					productid++;
				} else if (pricerange == 2) {
					// price = 15000;
					System.out.println("As per your choice we have:");
					System.out.println("Ram = 256 gb, color = Golden");
					System.out.println("We have available mobile stock of " + mobstock2);
					System.out.println("Please enter the quantity you want:");
					qun = sc.nextInt();
					if (qun <= mobstock2) {
						ram = 256;
						color = "golden";
						price = 15000;
						mobstock2 = mobstock2 - qun;
						amount = price * qun;
						Product pro = new Product(qun, price, productid, color, ram, company, amount);

						arr[i] = pro;
						System.out.println("Order is placed");
						// System.out.println("Order is placed");
					} else if (qun > mobstock2) {
						System.out.println("Sorry! Stock not available");
						System.out.println("Current stock is:");
						System.out.println(mobstock2);
					}
					productid++;
				}

			} else if (companyname == 2) {
				company = "Oppo";
				System.out.println("1 for range less than 10,000");
				System.out.println("2 for range between 10,000 to 20,000");
				System.out.println("3 for 20,000 to 50,000");
				System.out.println("4 for more than 50,000");
				System.out.println("Enter expected Price range choice:");
				int pricerange = sc.nextInt();
				if (pricerange == 1) {
					// float price = 5000;
					System.out.println("As per your choice we have:");
					System.out.println("Ram = 128 gb, color = Black, Price = Rs.5000");
					System.out.println("We have available mobile stock of " + mobstock1);
					System.out.println("Please enter the quantity you want:");
					qun = sc.nextInt();

					if (qun <= mobstock1) {
						ram = 128;
						color = "black";
						price = 5000;
						mobstock1 = mobstock1 - qun;
						amount = price * qun;
						Product pro = new Product(qun, price, productid, color, ram, company, amount);

						arr[i] = pro;
						System.out.println("Order is placed");

					} else if (qun > mobstock1) {
						System.out.println("Sorry! Stock not available");
						System.out.println("Current stock is:");
						System.out.println(mobstock2);
					}
					productid++;
				} else if (pricerange == 2) {
					// price = 15000;
					System.out.println("As per your choice we have:");
					System.out.println("Ram = 256 gb, color = Golden");
					System.out.println("We have available mobile stock of " + mobstock2);
					System.out.println("Please enter the quantity you want:");
					qun = sc.nextInt();
					if (qun <= mobstock2) {
						ram = 256;
						color = "golden";
						price = 15000;
						mobstock2 = mobstock2 - qun;
						amount = price * qun;
						Product pro = new Product(qun, price, productid, color, ram, company, amount);

						arr[i] = pro;
						System.out.println("Order is placed");

						// System.out.println("Order is placed");
					} else if (qun > mobstock2) {
						System.out.println("Sorry! Stock not available");
						System.out.println("Current stock is:");
						System.out.println(mobstock2);
					}
					productid++;
				}

			}

			else {
				System.out.println("Enter the valid choice for company name");
			}

		}
	}
	void deleteproduct() {
		int flag = 0;
		System.out.println("Enter the product id to delete: ");
		int updateddelete = sc.nextInt();
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == null) {
				continue;
			}
			if (arr[i].product_id == updateddelete) {
				flag = 1;
				arr[i] = null;
				System.out.println("Product deleted");
				break;
			} else {
				flag = 0;
			}
		}
		if (flag == 0) {
			System.out.println("Product not exist");
		}
	}
	void searchproduct() {
		int flag = 0;
		int id = 0;
		System.out.println("Enter the product id to search: ");
		int updatedsearch = sc.nextInt();
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == null) {
				continue;
			} else if (arr[i].product_id == updatedsearch) {
				flag = 1;
				System.out.println("Product id :" + arr[i].product_id);
				System.out.println("Companyname :" + arr[i].companyname);
				System.out.println("Quantity :" + arr[i].quantity);
				System.out.println("Price :" + arr[i].price);
				System.out.println("Ram :" + arr[i].ram);
				System.out.println("Color :" + arr[i].color);
				System.out.println("Total Price of product :" + arr[i].amount);
				break;
			}
		}
		if (flag == 0) {
			System.out.println("Product not exist");
		}
	}

	float calamount() {
		float total = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == null) {
				continue;
			} else {
				total = total + arr[i].amount;
			}
		}
		return total;
	}

	void displayproduct() {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == null) {
				continue;
			}
			System.out.println("Product id :" + arr[i].product_id);
			System.out.println("Companyname :" + arr[i].companyname);
			System.out.println("Quantity :" + arr[i].quantity);
			System.out.println("Price :" + arr[i].price);
			System.out.println("Ram :" + arr[i].ram);
			System.out.println("Color :" + arr[i].color);
			System.out.println("Price of product :" + arr[i].amount+"\n");
		}
	}
}

class CustomerList {
	Node head;
	String customer_name;
	int customer_id = 1;
	Scanner sc = new Scanner(System.in);

	CustomerList() {
		head = null;
	}

	void create() {
		System.out.println("Enter customer name :");
		customer_name = sc.next();
		Node temp = new Node(customer_name, customer_id);
		customer_id++;
		temp.insertOrder();
		if (head == null) {
			head = temp;
		} else {
			Node ptr = head;
			while (ptr.next != null) {
				ptr = ptr.next;
			}
			ptr.next = temp;
		}
	}

	void display_node() {
		Node ptr = head;
		if (ptr == null) {
			System.out.println("Customer List is empty");
		} else {
			System.out.println("Customer and their product details:");
			while (ptr != null) {
				System.out.println("Order displayed");
				System.out.println("Customer name is:" + ptr.customername + " ");
				System.out.println("Customer id is:" + ptr.customerid + " ");
				ptr.displayproduct();
				ptr = ptr.next;
				System.out.println("-------------------------------------------");
			}

		}
	}

	void search() {
		System.out.println("1. search customer \n2. search particular product of customer:");
		int ch = sc.nextInt();
		Node temp = head;
		if (temp == null) {
			System.out.println("Customer list is empty");
			return;
		}
		System.out.println("Enter customer id to search :");
		int key = sc.nextInt();
		if (ch == 1) {
			int flag = 0;
			temp = head;
			if (head == null) {
				System.out.println("Customer list is empty");
				return;
			}
			while (temp != null) {
				if (temp.customerid == key) {
					flag = 1;
					break;
				}
				temp = temp.next;
			}
			if (flag == 1) {
				temp.displayproduct();
			} else {
				System.out.println("Customer not found");
			}
		} else if (ch == 2) {
			temp = head;
			int flag = 0;
			if (head == null) {
				System.out.println("Customer list is empty");
				return;
			}
			while (temp != null) {
				if (temp.customerid == key) {
					flag = 1;
					break;
				}
				temp = temp.next;
			}

			if (flag == 1) {
				temp.searchproduct();
			} else {
				System.out.println("Customer not found");
			}
		}
	}

	void delete_node() {
		Node temp = head;
		Node prev = null;
		System.out.println("1. delete customer \n2. delete particular product of customer:");
		int ch = sc.nextInt();
		if (temp == null) {
			System.out.println("Customer list is empty");
			return;
		}
		System.out.println("Enter customer id to delete :");
		int key = sc.nextInt();
		if (ch == 1) {

			if (temp != null && temp.customerid == key) {
				head = temp.next; // Changed head
				System.out.println("customer are deleted");
				return;
			}
			while (temp != null && temp.customerid != key) {
				prev = temp;
				temp = temp.next;
			}
			if (temp == null) {
				System.out.println("Customer id is not found");
				return;
			}
			prev.next = temp.next;
			System.out.println("customer is deleted");

		} else if (ch == 2) {
			temp = head;
			int flag = 0;
			while (temp != null) {
				if (temp.customerid == key) {
					flag = 1;
					break;
				}
				temp = temp.next;
			}

			if (flag == 1) {
				temp.deleteproduct();
			} else {
				System.out.println("Customer not found");
			}
		}
	}

	void billGeneration() {
		System.out.println("Enter customer id to generate bill :");
		int d = sc.nextInt();
		Node temp = head;
		int flag = 0;
		if (temp == null) {
			System.out.println("Customer list is empty");
			return;
		} 
		else 
		{
			while (temp != null) {
				if (temp.customerid == d) {
					flag = 1;
					break;
				}
				temp = temp.next;
			}
		}
		if (flag == 1) 
		{
			System.out.println("Customer name :"+temp.customername);
			System.out.println("Customer ID :"+temp.customerid);
			System.out.println("-------------------------------------------");
			temp.displayproduct();
			Node prev=null;
			temp=head;
			System.out.println("-------------------------------------------");
			System.out.println("The total amount of mobile :" + temp.calamount() + " ");
			System.out.println("-------------------------------------------");
			if (temp != null && temp.customerid == d) {
				head = temp.next; // Changed head
				System.out.println("customer are deleted");
				return;
			}
			while (temp != null && temp.customerid != d) {
				prev = temp;
				temp = temp.next;
			}
			if (temp == null) {
				System.out.println("Customer id is not found");
				return;
			}
			prev.next = temp.next;
			System.out.println("order is delivered");
		} 
		else 
		{
			System.out.println("Customer id is not present");
		}
	}

}

public class Mobile {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		CustomerList cus = new CustomerList();
		int ch;

		do {
			System.out.println("1.Buy a Mobile \n2.Search a Mobile \n3.Display List \n4.Delete Customer \n5.Bill Generation");
			System.out.println("Enter the choice :");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				cus.create();
				break;
			case 2:
				cus.search();
				break;
			case 3:
				cus.display_node();
				break;

			case 4:
				cus.delete_node();
				break;
			case 5:
				cus.billGeneration();
				break;
			default:
				System.out.println("Please choose correct choice .");
				break;
			}
			System.out.println("Do you want to continue (1/0) :");
			ch = sc.nextInt();
			
			System.out.println("Thank you for visiting Shopping Center !");
		} while (ch != 0);
	}
}